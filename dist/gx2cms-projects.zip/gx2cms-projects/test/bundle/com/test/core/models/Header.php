<?php

namespace com\test\core\models;

use JsonSerializable;

class Header implements JsonSerializable
{
    private $data = [];

    public function __construct()
    {
        $this->data = [
            'properties' => [
                'heading' => 'Heading from PHP Model ' . get_called_class(),
                'subHeading' => 'My Sub Heading',
                'pageHeadingClass' => 'contact-me'
            ]
        ];
    }

    public function jsonSerialize()
    {
        return $this->data;
    }
}