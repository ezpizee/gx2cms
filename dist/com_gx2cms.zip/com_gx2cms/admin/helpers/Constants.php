<?php

class Constants
{
    const DB_TB_GX2CMS = "#__gx2cms";
}