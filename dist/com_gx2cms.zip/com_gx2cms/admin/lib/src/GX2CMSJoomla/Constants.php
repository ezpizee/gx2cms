<?php

namespace GX2CMSJoomla;

final class Constants
{
    private function __construct(){ }

    const EXT = "gx2cms";
    const KEY_FS_FILE = "fs_file";
}