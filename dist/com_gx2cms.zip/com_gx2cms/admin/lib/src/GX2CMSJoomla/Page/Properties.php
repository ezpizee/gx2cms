<?php

namespace GX2CMSJoomla\Page;

use Ezpizee\Utils\ListModel;

class Properties extends ListModel {}