<?php
if (!defined('EZPIZEE_DS')) {define('EZPIZEE_DS', DIRECTORY_SEPARATOR);}
include_once __DIR__ . EZPIZEE_DS . 'vendor' . EZPIZEE_DS . 'autoload.php';